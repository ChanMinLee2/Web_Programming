import React from "react";

function MainPage() {
  return <div>메인</div>;
}

export default MainPage;
