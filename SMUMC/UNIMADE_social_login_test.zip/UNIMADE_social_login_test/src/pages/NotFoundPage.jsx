import React from "react";

function NotFoundPage() {
  return <div>에러</div>;
}

export default NotFoundPage;
